package com.cg.capcafe.service;

import java.util.List;

import com.cg.capcafe.dto.Cafe;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.FoodItem;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Transaction;

public interface ITransactionService 
{
	public double payment(Order order,Employee employee);
	
	public Transaction addTransaction(Transaction transaction);
	
	public Transaction getTransactionById(int empId);
	
	public List<Transaction> getAllTransaction(); 
}
