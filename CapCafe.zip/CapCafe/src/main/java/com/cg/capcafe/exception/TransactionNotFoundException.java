package com.cg.capcafe.exception;

public class TransactionNotFoundException extends RuntimeException
{
	public TransactionNotFoundException(String exception)
	{
		super(exception);
	}
	
	TransactionNotFoundException()
	{
		
	}
}
