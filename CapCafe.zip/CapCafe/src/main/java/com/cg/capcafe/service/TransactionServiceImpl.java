package com.cg.capcafe.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capcafe.dto.Cafe;
import com.cg.capcafe.dto.Employee;
import com.cg.capcafe.dto.FoodItem;
import com.cg.capcafe.dto.Order;
import com.cg.capcafe.dto.Ticket;
import com.cg.capcafe.dto.Transaction;
import com.cg.capcafe.exception.EmployeeNotFoundException;
import com.cg.capcafe.exception.TransactionNotFoundException;
import com.cg.capcafe.repository.EmployeeRepository;
import com.cg.capcafe.repository.OrderRepository;
import com.cg.capcafe.repository.TransactionRepository;

@Service
@Transactional
public class TransactionServiceImpl implements ITransactionService 
{
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public double payment(Order order, Employee employee) 
	{
		double total_amt = 0;
	
		Employee emp = employeeRepository.findById(employee.getEmpId()).get();
		 for (Order iterable_element : emp.getPastOrders()) 
		 {
			total_amt=total_amt+iterable_element.getTotalAmount();
		 }
		if(emp != null)
		{
			
			String emp_name =	emp.getName();
			String emp_email = emp.getEmail();
			
			
			double walletAmount = employee.getWallet(); //wallet Amount
			double orderAmount = total_amt;	// Order Amount
		
			walletAmount = walletAmount - orderAmount;
			employee.setWallet(walletAmount);//employee
			order.setTotalAmount(orderAmount);
			
			
			Transaction transaction = new Transaction();
			transaction.setOrder(order);
			transaction.setTimestamp(LocalDateTime.now());
			transaction.setPaymentMode("Card");
			
			 transactionRepository.save(transaction);
			 return orderAmount;
		}
		else
		{
			throw new EmployeeNotFoundException("Employee not Found");
		}
		
		
	}

	@Override
	public Transaction addTransaction(Transaction transaction) 
	{
		return transactionRepository.save(transaction);
	}

	@Override
	public Transaction getTransactionById(int empId) 
	{
		Transaction transaction=null;// =  transactionRepository.getByEmpId(empId);
		
		if(transaction == null)
		{
			throw new TransactionNotFoundException("Transaction not found with Employee Id: "+empId);
		}
		
		return transaction;
	}

	@Override
	public List<Transaction> getAllTransaction() 
	{
		List<Transaction> allTransaction = transactionRepository.findAll();
		
		if(allTransaction.isEmpty())
		{
			throw new TransactionNotFoundException("No transaction found");
		}
		
		return allTransaction;
	}
	
}
