package com.cg.capcafe.exception;


/**
 * @author Sameer Mandavia
 * Class name:- TicketNotFoundException
 * 
 * 
 * */


public class TicketNotFoundException extends RuntimeException 
{
	
	public TicketNotFoundException(String exception)
	{
		super(exception);
	}
	
}
