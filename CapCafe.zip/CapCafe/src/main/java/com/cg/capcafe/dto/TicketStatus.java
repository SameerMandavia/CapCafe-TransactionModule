package com.cg.capcafe.dto;

public enum TicketStatus {
	UNRESOLVED,
	RESOLVED
}
